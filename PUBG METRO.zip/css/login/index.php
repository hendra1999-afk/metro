Why do you stay here?

Nothing here, please leave here.

If you don't leave, my spirit will terrorize you.