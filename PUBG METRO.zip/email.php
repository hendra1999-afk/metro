<?php
$emailku = 'akunnuyul362@gmail.com'; // GANTI EMAIL KAMU DISINI
?>